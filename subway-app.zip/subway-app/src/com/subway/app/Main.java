package com.subway.app;

import com.subway.app.order.Invoice;
import com.subway.app.order.Order;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Welcome to Subway:");
        System.out.println("1) Order 'Sub' of the day");
        System.out.println("2) Order your own 'Sub'");
        System.out.println("3) Exit");

        int input = sc.nextInt();

        Order order = new Order();

        switch (input) {
            case 1:
                var order1 = new Order().createRandom();
                Invoice.generate(order1);
                System.out.println("Your subway order is placed for " + order1.getTotal() + " rupees");
                System.exit(0);
                break;

            case 2:
                var order2 = new Order().create();
                Invoice.generate(order2);
                System.out.println("Your subway order is placed for " + order2.getTotal() + " rupees");
                System.exit(0);
                break;

            case 3:
                System.exit(0);
                break;

            default:
                break;
        }

    }
}
