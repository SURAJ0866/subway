package com.subway.app.ingredients;

public enum Filling {
    CHICKEN_TIKKA(120), PANEER_TIKKA(100), TURKEY_MEAT(130);

    private int price;

    Filling(int price) {
        this.price = price;
    }

    public int getPrice() {
        return price;
    }

}
