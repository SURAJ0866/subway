package com.subway.app.ingredients;

public enum Crust {
    HARD(10), THIN(10), SOFT(12);

    private int price;

    Crust(int price) {
        this.price = price;
    }

    public int getPrice() {
        return price;
    }
}
