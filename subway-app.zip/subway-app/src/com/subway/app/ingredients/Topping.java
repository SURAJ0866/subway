package com.subway.app.ingredients;

public enum Topping {
    CUCUMBER(25), TOMATO(20), MEAT_STRIP(45), CABBAGE(20);
    private int price;

    Topping(int price) {
        this.price = price;
    }

    public int getPrice() {
        return price;
    }
}
