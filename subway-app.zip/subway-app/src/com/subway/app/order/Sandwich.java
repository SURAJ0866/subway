package com.subway.app.order;

import com.subway.app.ingredients.Crust;
import com.subway.app.ingredients.Filling;
import com.subway.app.ingredients.Topping;

public class Sandwich {
    private Crust crust;
    private Filling filling;
    private Topping[] toppings;

    public Crust getCrust() {
        return crust;
    }

    public void setCrust(Crust crust) {
        this.crust = crust;
    }

    public Filling getFilling() {
        return filling;
    }

    public void setFilling(Filling filling) {
        this.filling = filling;
    }

    public Topping[] getToppings() {
        return toppings;
    }

    public void setToppings(Topping[] toppings) {
        this.toppings = toppings;
    }
}
