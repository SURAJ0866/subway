package com.subway.app.order;

import com.subway.app.ingredients.Topping;

import java.io.IOException;

public class Invoice {

    public static void generate(Order order) {
        var sandwich = order.getSandwich();
        int total = order.getTotal();
        Topping freeTopping = order.getFreeTopping();

        System.out.println("Invoice for Sub");
        System.out.println("Crust - " + sandwich.getCrust() + " - " + sandwich.getCrust().getPrice());
        System.out.println("Filling - " + sandwich.getFilling() + " - " + sandwich.getFilling().getPrice());

        var toppings = sandwich.getToppings();

        for (int i = 0; i < sandwich.getToppings().length; i++) {
            if(toppings[i] != null) {
                if (toppings[i].equals(freeTopping)) {
                    System.out.println("Topping - " + toppings[i] + " - 0");
                } else {
                    System.out.println("Topping - " + toppings[i] + " - " + toppings[i].getPrice());
                }
            }
        }

        System.out.println("Total - " + total);

        try {
            System.in.read();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
