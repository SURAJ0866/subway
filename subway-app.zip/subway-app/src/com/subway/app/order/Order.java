package com.subway.app.order;

import com.subway.app.ingredients.Crust;
import com.subway.app.ingredients.Filling;
import com.subway.app.ingredients.Topping;

import java.util.Random;
import java.util.Scanner;

public class Order {
    private static final Scanner sc = new Scanner(System.in);
    private Sandwich sandwich;
    private int total;
    private Topping freeTopping;


    public Topping getFreeTopping() {
        return freeTopping;
    }

    private void setFreeTopping(Topping freeTopping) {
        this.freeTopping = freeTopping;
    }

    public Sandwich getSandwich() {
        return sandwich;
    }

    public void setSandwich(Sandwich sandwich) {
        this.sandwich = sandwich;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public Order createRandom() {
        Random random = new Random();
        int c = random.nextInt(Crust.values().length);
        int t = random.nextInt(Topping.values().length);
        int f = random.nextInt(Filling.values().length);
        sandwich = new Sandwich();

        sandwich.setToppings(new Topping[]{Topping.values()[t]});
        sandwich.setFilling(Filling.values()[f]);
        sandwich.setCrust(Crust.values()[c]);

        calculateCrust(Crust.values()[c]);
        calculateFillings(Filling.values()[f]);
        calculateToppings(new Topping[]{Topping.values()[t]});

        Order order = new Order();
        order.setSandwich(sandwich);
        order.setTotal(total);

        return order;
    }

//    Creating Order
    public Order create() {
        Sandwich sandwich = new Sandwich();

        selectCrust(sandwich);
        selectFilling(sandwich);
        selectToppings(sandwich);

        Order order = new Order();
        order.setSandwich(sandwich);
        order.setTotal(calculateTotal(sandwich));
        order.setFreeTopping(getFreeTopping());
        return order;
    }

    private int calculateTotal(Sandwich sandwich) {
        calculateCrust(sandwich.getCrust());
        calculateFillings(sandwich.getFilling());
        calculateToppings(sandwich.getToppings());

        return total;
    }

    private void calculateToppings(Topping[] toppings) {
        int totalElements = totalToppings(toppings);
        if (totalElements > 2) {
//            Sort the topping prices in descending order
            sort(toppings);
            setFreeTopping(toppings[toppings.length - 1]); // Setting free topping

            for (int i = 0; i < toppings.length - 1; i++) {
                total += toppings[i].getPrice();
            }
        } else {
            for (int i = 0; i < totalElements; i++) {
                total += toppings[i].getPrice();
            }
        }

    }

    private int totalToppings(Topping[] toppings) {
        int count = 0;

        for (int i = 0; i < toppings.length; i++) {
            if (toppings[i] != null) {
                count++;
            }
        }

        return count;
    }

    private void sort(Topping[] toppings) {
        for (int i = 0; i < toppings.length - 1; i++) {
            for (int j = i + 1; j < toppings.length; j++) {
                if (toppings[i].getPrice() < toppings[j].getPrice()) {
                    Topping temp = toppings[i];
                    toppings[i] = toppings[j];
                    toppings[j] = temp;
                }
            }
        }
    }

    private void calculateFillings(Filling filling) {
        total += filling.getPrice();
    }

    private void calculateCrust(Crust crust) {
        total += crust.getPrice();
    }

    private void selectToppings(Sandwich sandwich) {
        System.out.println("Select Toppings(max 3)");
        System.out.println("    1) Cucumber - 25 Rupees");
        System.out.println("    2) Tomato - 20 Rupees");
        System.out.println("    3) Meat Strip - 45 Rupees");
        System.out.println("    4) Cabbage - 20 Rupees");
        sc.nextLine();
        String line = sc.nextLine();
        String[] input = line.split(",");
        Topping[] toppings = new Topping[input.length];
        int idx = 0;
        for (int i = 0; i < input.length; i++) {
            int pos = Integer.parseInt(input[i]);
            System.out.println(pos);
            if (sandwich.getFilling().equals(Filling.PANEER_TIKKA) && (Topping.values()[pos - 1].equals(Topping.MEAT_STRIP))) {
                continue;
            }
            toppings[idx++] = Topping.values()[pos - 1];
        }

        sandwich.setToppings(toppings);
    }

    private void selectFilling(Sandwich sandwich) {
        System.out.println("Select Filling(max 1)");
        System.out.println("    1) Chicken Tikka- 120 Rupees");
        System.out.println("    2) Panner Tikka- 100 Rupees");
        System.out.println("    3) Turkey Meat- 130 Rupees");

        int input = sc.nextInt();

        switch (input) {
            case 1:
                sandwich.setFilling(Filling.CHICKEN_TIKKA);
                break;
            case 2:
                sandwich.setFilling(Filling.PANEER_TIKKA);
                break;
            case 3:
                sandwich.setFilling(Filling.TURKEY_MEAT);
                break;
            default:
                break;
        }
    }

    private void selectCrust(Sandwich sandwich) {
        System.out.println("Select Crust(max 1)");
        System.out.println("    1) Hard- 10 Rupees");
        System.out.println("    2) Thin- 10 Rupees");
        System.out.println("    3) Soft- 12 Rupees");

        int input = sc.nextInt();

        switch (input) {
            case 1:
                sandwich.setCrust(Crust.HARD);
                break;
            case 2:
                sandwich.setCrust(Crust.THIN);
                break;
            case 3:
                sandwich.setCrust(Crust.SOFT);
                break;
            default:
                break;
        }
    }
}
